// las Higher Order functions (o funciones de orden superior) siguen este mismo principio de generalizacion

const array = [1, 2, 3, 4, 5, 6, 7]

// supongamos que quiero imprimir el doble de cada uno de los elementos del arreglo
for (let num of array) {
    // console.log(num * 2)
}

// digamos que ahora quiero obtener los resultados y meterlos en un arreglo nuevo y 
// que espero utilizar estas copias en varias partes de mi aplicacion 
const newArray = []
for (let num of array) {
    newArray.push(num * 2)
}

// modulo 1 de mi aplicacion
// console.log(newArray)

// modulo 2 de mi aplicacion
const newArray2 = []
for (let num of array) {
    newArray2.push(num * 2)
}
// console.log('modulo2', newArray2)

// DRY - DO NOT REPEAT YOURSELF
function copyArrayAndMultiplyBy2(array) {
    const myNewArray = []
    for (let num of array) {
        myNewArray.push(num * 2)
    }

    return myNewArray
}

// ahora supongamos que no quiero el doble, sino el triple?

// DRY - DO NOT REPEAT YOURSELF
function copyArrayAndMultiplyByMultiplier(array, multiplicador) {
    const myNewArray = []
    for (let num of array) {
        myNewArray.push(num * multiplicador)
    }

    return myNewArray
}

// console.log(copyArrayAndMultiplyByMultiplier(array, 10))

// ahora supongamos que no quiero el triple, sino el resultado de la division sobre 2 del numero
function copyArrayAndOperateByOperator(array, operando, operator) {
    const myNewArray = []
    for (let num of array) {
        switch(operator) {
            case "+":
                myNewArray.push(num + operando)
                break;
            case "-":
                myNewArray.push(num - operando)
                break;
            case "*":
                myNewArray.push(num * operando)
                break;
            default:
                myNewArray.push(num / operando)
        }
    }

    return myNewArray
}

// console.log(copyArrayAndOperateByOperator(array, 10, '+'))
// console.log(copyArrayAndOperateByOperator(array, 10, '-'))
// console.log(copyArrayAndOperateByOperator(array, 10, '*'))
// console.log(copyArrayAndOperateByOperator(array, 10, '/'))

// reimplementemos esto usando higher order functions
function myFirstHOF(array, num, cb) {
    const newArray = [];
    for (let element of array) {
        newArray.push(cb(element, num))
    }

    return newArray
}

/* console.log(myFirstHOF(array, 10, function(element, num) {
    return element + num
}))

console.log(myFirstHOF(array, 10, function(element, num) {
    return element - num
}))

console.log(myFirstHOF(array, 10, function(element, num) {
    return element * num
}))

console.log(myFirstHOF(array, " fue el numero", function(element, num) {
    return element + num
})) */

console.log(array.map((element) => element * 10))
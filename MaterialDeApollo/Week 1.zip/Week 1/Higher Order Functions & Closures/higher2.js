// Generalizamos las funciones para hacerlas reutilizables

function squareNum(num) {
    return num * num
}

console.log(squareNum(4))
console.log(squareNum(5))
console.log(squareNum(17))
console.log(squareNum(9))

// Que es lo que nos permite generalizar las funciones?
// --> Parametros

// En el ejemplo anterior que es lo que generalizamos?
// --> Data --> 10

// Una funcion maneja 2 cosas:
    // * Data o informacion
    // * Instrucciones o codigo, comportamiento 
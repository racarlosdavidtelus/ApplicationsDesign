// Que usos utiles les podriamos dar?

// 1. Construir iteradores
function myIterator(array) {
    let index = 0;
    return function() {
        if (index >= array.length)
            index = 0;

        console.log(array[index++])
    }
}

const array = ["Alicia", "Javier", "Alejandra", "Josue", "Josue"]
const iterator = myIterator(array)
iterator()
iterator()
iterator()

// 2. Funciones de programacion funcional, como once
// -> esta la vamos a implementar entre todos 
function myFunction() {
    console.log("Hello, World!")
}

function once() {

}

const myFunctionOnce = once(myFunction);
myFunctionOnce()
// no me tiene que dejar
myFunctionOnce()
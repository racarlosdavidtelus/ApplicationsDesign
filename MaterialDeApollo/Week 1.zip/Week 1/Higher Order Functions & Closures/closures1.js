// Anteriormente platicamos de las particularidades que tienen las funciones en javascript

// 1. Pueden ser usadas como expresiones:
const myFunction = function() {
    console.log("this is my function")
}

myFunction()

// 2. Pueden ser utilizadas como parametros, asi como vimos con HOF
function higherOrderFunction(callback, option) {
    if (option)
        callback()
    else 
        console.log("Decidimos no ejecutar la funcion")
}

function myCallback() {
    console.log("Decidimos que era buena idea ejecutar la funcion")
}

higherOrderFunction(myCallback, true)

// 3. Como las funciones pueden ser utilizadas como expresiones tambien pueden ser retornadas por otras funciones 
function myClosure() {
    return function() {
        console.log("este es mi closure")
    }
}

const closureF = myClosure()
closureF()
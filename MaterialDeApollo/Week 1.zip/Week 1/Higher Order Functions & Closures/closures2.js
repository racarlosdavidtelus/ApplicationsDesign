// Los closures son muy utiles, porque nos permiten tener una memoria "privada" por asi decirlo

function myCounterClosure() {
    let counter = 0;
    
    return function() {
        console.log(counter++)
    }
}

const myFirstClosure = myCounterClosure()
// myFirstClosure
myFirstClosure() // --> 0
myFirstClosure() // --> 1
myFirstClosure() // --> 2

const mySecondClosure = myCounterClosure()
// mySecondClosure
mySecondClosure() // --> 0

myFirstClosure() // --> 3
/* 
    1. Que significa DRY?
    2. Que es una funcion y por que las usamos?
    3. Que particularidades tienen las funciones en javascript?
*/

// Los ejemplos fueron obtenidos en un curso de frontendMasters, dado por Will Sentance

function tenSquared() {
    return 10 * 10;
}

console.log(tenSquared())

// Si todas las funciones se escribieran asi como le hariamos para escribir una 
// funcion que devuelva un 9 al cuadrado?
// --> 

function nineSquared() {
    return 9 * 9
}

console.log(nineSquared())


console.log(tenSquared())




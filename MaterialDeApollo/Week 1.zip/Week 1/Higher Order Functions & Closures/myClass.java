class myClass {

    private int myCounter;
    public myClass() {
        myCounter = 0;
    }

    public increaseCounter() {
        myCounter++;
    }
}
// Primera forma de crear objetos: construyendo una funcion generadora
// --> Guardar las funciones junto con su informacion asociada

function userCreator(name, age) {
    const newUser = {};
    newUser.name = name;
    newUser.age = age;
    newUser.incrementAge = function() {
        this.age++;
        console.log(this.name, this.age)
    }
    return newUser;
}

const user1 = userCreator('Javier', 25)
user1.incrementAge()

const user2 = userCreator('Manuel', 30)
user2.incrementAge()

const user3 = userCreator('Andrea', 22)
user3.incrementAge()

console.log(user1.incrementAge === user2.incrementAge)

// Que desventajas ven con esta forma de crear sus objetos?

// BONUS - Scope dinamico
// user1.incrementAge.call({ name: 'Tono', age: 1})
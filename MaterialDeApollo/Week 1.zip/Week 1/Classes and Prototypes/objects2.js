// Opcion 2: Podemos usar la cadena de prototipos 
function userCreator(name, age) {
    const newUser = Object.create(userFunctionStore)
    newUser.name = name;
    newUser.age = age;
    return newUser;
}

const anotherObject = {
    printName() {
        console.log(this.name)
    },

    printNameAndAge() {
        console.log(`Name: ${this.name}, Age: ${this.age}`)
        console.log(this.hasOwnProperty('myProp'))
    }
}

const userFunctionStore = Object.create(anotherObject)
userFunctionStore.incrementAge = function () {
    this.age++;
    console.log(this.age)
}

const user1 = userCreator('Javier', 25)
user1.incrementAge()
user1.printNameAndAge()
// Opcion 4: Syntactic Sugar
class User {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }

    incrementAge() {
        this.age++;
        console.log(this.age);
    }
}

const user1 = new User("Alejandro", 24)
user1.incrementAge()
// Opcion 3: new keyword --> https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/new
function User(name, age) {
    this.name = name;
    this.age = age;
}

User.prototype.incrementAge = function () {
    this.age++;
    console.log(this.age)
}

function Dogs(name) {
}

Dogs.prototype = User.prototype

console.log((new Dogs).incrementAge)

/* User.prototype = {
    // incrementAge() {
        // this.age++
        //console.log(this.age)
    },

    printName() {
        console.log(this.name)
    }
} */

const user2 = new User('Josue', 22)
const user1 = new User('Javier', 23)
console.log(user1.incrementAge === user2.incrementAge)
// console.log(user2.hasOwnProperty('myProp'))
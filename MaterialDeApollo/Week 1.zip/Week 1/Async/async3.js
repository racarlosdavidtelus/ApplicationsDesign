console.log("What should be printed first?")

setTimeout(() => {
    console.log('Hello, World!?')
}, 0)

console.log("This?")
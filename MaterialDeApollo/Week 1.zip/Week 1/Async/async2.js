console.log("What should be printed first?")

setTimeout(() => {
    console.log('Hello, World!?')
}, 3000)

console.log("This?")
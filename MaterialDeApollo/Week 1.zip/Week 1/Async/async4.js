console.log("What should be printed first?")

async function myFunc() {
    setTimeout(() => {
        console.log('Hello, World!?')
    }, 1000)
}

async function myOtherFunc() {
    myFunc().then(() => {
        console.log("print lo que sea")
    })
    console.log("print lo que sea")
}

myOtherFunc()

while (true) {
    // do stuff
}
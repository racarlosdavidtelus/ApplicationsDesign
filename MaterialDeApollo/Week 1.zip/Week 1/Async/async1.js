setTimeout(() => {
    console.log('Hello, World!')
}, 1000)